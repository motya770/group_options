var Graph = {
    _graph: null,
    init: function () {
        var data = [];
        $('#graph-container').highcharts('StockChart', {

            rangeSelector: {
                enabled: false
            },

            title: {
                text: ''
            },

            series: [{
                name: 'AAPL',
                data: data,
                tooltip: {
                    valueDecimals: 2
                }
            }]
        });
    },
    _setupTechnicalAnalysesLink: function (assetExternalId) {
        $(".technical-analysis a").attr("href", "/technical-analysis?assetExternalId=" + assetExternalId.replace("/", ""));
    },
    currentAssetExternalId: function(){
        return $(".graph-block .graph-header .asset-external-id").text().trim();
    },
    addQuoteToGraph: function (price, time) {
        var timeValue = parseInt(time);
        var priceValue = parseFloat(price);

        /*
         var i = Math.floor((Math.random() * 2) + 1);
         Graph._graph.chartBackground.css(
         {
         color: '#555555'
         });*/
        /*
         var gradient = {
         linearGradient: [0, 0, 0, 400],
         stops: [ [0, 'rgb(96, 96, 96)'],
         [1, 'rgb(16, 16, 16)'] ]
         };
         Graph._graph.series[0].fillColor = gradient;
         */
        /*Graph._graph.chartBackground.attr({
         fill:gradient
         });*/
        /*
         if(i==1) {
         //Graph._graph.series[0].fillColor = "#FF0000";
         Graph._graph.series[0].color = "#FF0000";
         Graph._graph.series[0].graph.attr({stroke: '#FF0000'});
         }else if(i==2){
         //Graph._graph.series[0].fillColor = "#00FF00";
         Graph._graph.series[0].color = "#00FF00";
         Graph._graph.series[0].graph.attr({stroke: '#00FF00'});
         }*/

        Graph._graph.series[0].addPoint([timeValue, priceValue], true, false);

    },
    _addFlag: function (positionOpenTime) {
        var positionFlag = {
            turboThreshold: 0,
            id: "flagSeries",
            allowPointSelect: true,
            type: 'flags',
            data: [{
                x: positionOpenTime,
                title: ' '
            }],
            onSeries: 'dataseries',
            shape: 'url(/resources/images/main/open_pos.png)',
            width: 16
        };
        return positionFlag;
    },
    _addNewPositionFlag: function (positionOpenTime) {

        var flagPoint = {
            x: positionOpenTime,
            turboThreshold: 0,
            title: ' '
        };
        //Graph._graph.series[1].turboThreshold = 0;
        Graph._graph.series[1].addPoint(flagPoint);
    },
    _loadGraphData: function (assetExternalId, bidStartTime, tradeTime, closeTime, positionGraph, positions) {
        Graph._setupTechnicalAnalysesLink(assetExternalId);
        $(".graph-header .asset-name").text(assetExternalId);
        $(".graph-header .asset-external-id").text(assetExternalId);

        var startRange = bidStartTime - 30000;
        var endRange = closeTime;

        var url = "";
        if (positionGraph) {
            url = "/graph/get-position-quotes?assetExternalId=" +
            assetExternalId + "&openTime=" + (bidStartTime - 30000) + "&closeTime=" + (closeTime);
        } else {
            url = '/graph/get-asset-quotes?assetExternalId=' + assetExternalId;
        }

        $.getJSON(url, function (data) {
            if (data.error) {
                Notifications.error(data.message);
                return;
            }
            // Create the chart
            var formattedData = [data.length + 1];

            for (var i in data) {
                var point = new Array(2);
                //console.log(data[i].time + " " + new Date(data[i].time));
                point[0] = data[i].time;
                point[1] = data[i].value;
                formattedData[i] = point;
            }

            var series = [{
                id: 'dataseries',
                threshold: null,
                type: 'area',
                name: assetExternalId,
                data: formattedData,
                tooltip: {
                    //valueDecimals: 2
                }
                , fillColor: {
                    linearGradient: {
                        x1: 0,
                        y1: 0,
                        x2: 0,
                        y2: 1
                    },

                    stops: [
                        [0, Highcharts.getOptions().colors[0]],
                        [1, Highcharts.Color(Highcharts.getOptions().colors[0]).setOpacity(0).get('rgba')]
                    ]
                }
            }, {
                turboThreshold: 0,
                id: "flagSeries",
                allowPointSelect: true,
                type: 'flags',
                data: [],
                onSeries: 'dataseries',
                shape: 'url(/resources/images/main/open_pos.png)',
                width: 16
            }];

            $(positions).each(function () {
                console.log('test 1');
                var p = this;
                var positionOpenTime = parseInt($(".open-time", p).text());
                var positionFlag = Graph._addFlag(positionOpenTime);
                series.push(positionFlag);
            });

            Highcharts.setOptions({
                global : {
                    useUTC : false
                }
            });

            var chartOptions = {
                navigator: {
                    adaptToUpdatedData: false
                },
                rangeSelector: {
                    enabled: false
                },
                chart: {
                    renderTo: 'graph-container'
                },
                title: {
                    text: null
                },
                yAxis: {},
                xAxis: {
                    min: startRange,
                    max: endRange,
                    ordinal: false,
                    maxPadding: 0.5,
                    //minPadding: 0.2,
                    //startOnTick: false,
                    //endOnTick: false,
                    plotLines: [
                        {
                            color: 'blue', // Color value
                            // Style of the plot line. Default to solid
                            value: bidStartTime, // Value of where the line will appear
                            width: 4 // Width of the line
                        },
                        {
                            color: 'green', // Color value
                            // Style of the plot line. Default to solid
                            value: tradeTime, // Value of where the line will appear
                            width: 4 // Width of the line
                        },
                        {
                            color: 'red', // Color value
                            // Style of the plot line. Default to solid
                            value: closeTime, // Value of where the line will appear
                            width: 4 // Width of the line
                        }]
                },
                series: series
            }

            Graph._graph = new Highcharts.StockChart(chartOptions, function () {
            });
        });
    },
    loadPositionGraph: function (position) {

        var assetExternalId = $(".asset-external-id", position).text();
        var bidStartTime = parseInt($(".bid-start-time", position).text());
        var positionOpenTime = parseInt($(".open-time", position).text());
        var tradeTime = parseInt($(".trade-time", position).text());
        var closeTime = parseInt($(".close-time", position).text());

        var positions = new Array();
        positions.push(position);

        Graph._loadGraphData(assetExternalId, bidStartTime, tradeTime, closeTime, true, positions);
    },
    loadGraph: function () {
        var assetExternalId = Options.getSelectedAssetExternalId();
        if (assetExternalId == null || assetExternalId == "") {
            return;
        }
        var option = Options.getSelectedOption();
        var optionId = $(".option-id", option).text();

        var positions = $(".open-positions-container .open-positions .open-position.option-id-" + optionId);

        var bidStartTime = parseInt($(".open-time", option).text());
        var tradeTime = parseInt($(".trade-time", option).text())
        var closeTime = parseInt($(".close-time", option).text())

        Graph._loadGraphData(assetExternalId, bidStartTime, tradeTime, closeTime, false, positions);
    }
}