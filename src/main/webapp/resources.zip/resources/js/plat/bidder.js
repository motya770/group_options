var Bidder = {
    init: function () {
        $('.bidder-amount').on('input', function () {
            Bidder.bidderValueChanged();
        });
    },
    setBidderPrice: function (price, time) {
        $(".bidder .bidder-asset-price").text(price);
        $(".bidder .bidder-asset-quote-time").text(time);
    },

    loadBidder: function (option) {

        $(".bidder .bidder-buttons .bidder-button").removeClass("active");

        var assetName = $(".asset-name ", option).text();
        var assetExternalId = $(".asset-external-id", option).text().trim();
        var optionId = $(".option-id", option).text();

        $(".bidder").addClass("bidder-option-id-" + optionId);
        var bidderQuestion = $(".bidder .bidder-question").text();
        $(".bidder .bidder-asset").text(bidderQuestion + assetName + " ?");

        var winAmount = parseFloat($(".current-win-amount", option).text());
        var looseAmount = parseFloat($(".current-loose-amount", option).text());
        var bursaPercent = parseFloat($(".bursa-percent", option).text());

        $(".bidder .bidder-amount").val($(".bid-amount-picker option:selected" ).attr("data-value"));

        Options._calculateBidderAmounts(optionId, winAmount, looseAmount, bursaPercent);
    },
    bidderValueChanged: function () {
        var option = Options.getSelectedOption();
        var optionId = $(".option-id", option).text();

        var winAmount = parseFloat($(".current-win-amount", option).text());
        var looseAmount = parseFloat($(".current-loose-amount", option).text());
        var bursaPercent = parseFloat($(".bursa-percent", option).text());

        Options._calculateBidderAmounts(optionId, winAmount, looseAmount, bursaPercent);
    },
    selectDirection: function (directionButton) {

        $(".bidder .bidder-buttons .bidder-button").removeClass("button-selected");
        $(".bidder .bidder-buttons .bidder-button").removeClass("active");
        $(directionButton).addClass("active");
        $(directionButton).addClass("button-selected");
    }
}